﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS225CardLibrary
{
   public enum Ranks
   {
      Two = 2,
      Three,
      Four,
      Five,
      Six,
      Seven,
      Eight,
      Nine,
      Ten,
      Jack,
      Queen,
      King,
      Ace
   }
}
