﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS225CardLibrary
{
   public enum Suits
   {
      Club,
      Diamonds,
      Hearts,
      Spade,
   }
}
